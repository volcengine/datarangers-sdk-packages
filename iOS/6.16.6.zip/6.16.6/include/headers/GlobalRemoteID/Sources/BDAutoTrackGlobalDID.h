//
//  BDAutoTrackGlobalDID.h
//  ObjCExample
//
//  Created by bytedance on 2/15/23.
//  Copyright © 2023 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackGlobalDID : NSObject

@end

NS_ASSUME_NONNULL_END
