//
//  CLLocationManagerDelegate+AutoTrack.h
//  RangersAppLog
//
//  Created by bytedance on 2022/4/12.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>


@interface CLLocationManager (AutoTrack)

@end

