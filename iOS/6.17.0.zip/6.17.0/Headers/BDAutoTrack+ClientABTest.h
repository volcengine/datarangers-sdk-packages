//
//  BDAutoTrack+ClientABTest.h
//  Pods
//
//  Created by bytedance on 2023/9/27.
//

#import <Foundation/Foundation.h>
#import "BDAutoTrack.h"
#import "BDAutoTrackExperimentLayer.h"
#import "BDAutoTrackExperiment.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrack (ClientABTest)

- (void)addABClientExperimentLayer:(BDAutoTrackExperimentLayer *)layer;

- (void)addABClientExperiment:(BDAutoTrackExperiment *)experiment layerName:(NSString *)layerName;

- (void)removeABClientExperimentLayer:(BDAutoTrackExperimentLayer *)layer;

- (void)removeABClientExperimentLayerByName:(NSString *)layerName;

- (void)removeABClientExperiment:(BDAutoTrackExperiment *)experiment layerName:(NSString *)layerName;

- (void)clearABClientExposedVids;

@end

NS_ASSUME_NONNULL_END
