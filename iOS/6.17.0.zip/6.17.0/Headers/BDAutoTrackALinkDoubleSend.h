//
//  BDAutoTrackALinkDoubleSend.h
//  RangersAppLog
//
//  Created by ByteDance on 10/23/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackALinkDoubleSend : NSObject

/// 穿山甲双发请求URL
+ (NSString *)deferredALinkDoubleSendRequestUrlString;

@end

NS_ASSUME_NONNULL_END
