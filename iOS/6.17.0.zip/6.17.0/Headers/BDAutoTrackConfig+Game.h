//
//  BDAutoTrackConfig+Game.h
//  RangersAppLog
//
//  Created by ByteDance on 8/20/24.
//

#import "BDAutoTrackConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackConfig (Game)

/*! @abstract 游戏模式，开启游戏模式会默认上报游戏心跳事件 */
@property (nonatomic, assign) BOOL gameModeEnable;

@end

NS_ASSUME_NONNULL_END
