//
//  BDAutoTrackEncryptor.h
//  RangersAppLog
//
//  Created by SoulDiver on 2022/6/6.
//

#import <Foundation/Foundation.h>
#import "BDAutoTrackEncryptionDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackEncryptor : NSObject<BDAutoTrackEncryptionDelegate>



@end

NS_ASSUME_NONNULL_END
