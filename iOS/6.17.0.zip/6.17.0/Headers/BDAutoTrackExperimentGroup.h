//
//  BDAutoTrackExperimentGroup.h
//  Pods
//
//  Created by bytedance on 2023/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackExperimentGroup : NSObject

/*! @abstract 值 0-1
    @discussion 1 代表流量 100%
 */
@property (nonatomic, assign, readonly) CGFloat rate;
@property (nonatomic, copy, readonly) NSString *vid;
@property (nonatomic, strong, readonly) id value;

- (instancetype)initWithRate:(CGFloat)rate vid:(NSString *)vid value:(id)value;

@end

NS_ASSUME_NONNULL_END
