//
//  BDAutoTrackExperimentLayer.h
//  Pods
//
//  Created by bytedance on 2023/9/27.
//

#import <Foundation/Foundation.h>
#import "BDAutoTrackExperiment.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackExperimentLayer : NSObject

@property (nonatomic, copy, readonly) NSString *name;

- (instancetype)initWithName:(NSString *)name;

- (instancetype)initWithName:(NSString *)name experiments:(NSArray<BDAutoTrackExperiment *> *)experiments;

- (instancetype)initWithName:(NSString *)name experiment:(BDAutoTrackExperiment *)experiment;

- (NSArray<BDAutoTrackExperiment *> *)allExperiments;

- (void)addExperiment:(BDAutoTrackExperiment *)experiment;

- (void)removeExperiment:(BDAutoTrackExperiment *)experiment;

- (void)removeExperimentByKey:(NSString *)key;

- (BOOL)containsKey:(NSString *)key;

- (void)resetLayer;

- (void)generateNewRandomNumber;

@end

NS_ASSUME_NONNULL_END
