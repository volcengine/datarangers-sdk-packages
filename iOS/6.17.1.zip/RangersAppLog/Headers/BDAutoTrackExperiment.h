//
//  BDAutoTrackExperiment.h
//  Pods
//
//  Created by bytedance on 2023/9/27.
//

#import <Foundation/Foundation.h>
#import "BDAutoTrackExperimentGroup.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDAutoTrackExperiment : NSObject

@property (nonatomic, copy, readonly) NSString *key;

@property (nonatomic, readonly) NSMutableArray *groups;

@property (nonatomic, weak) BDAutoTrackExperimentGroup *hitGroup;

- (NSArray *)vidLists;

/**
 实验的初始化
 
 @param key 实验key，必须与abtest平台的“配置参数”名字保持一致
 @param groups 实验组列表
 @return BDAutoTrackExperiment对象
 */
- (instancetype)initWithKey:(NSString *)key groups:(NSArray<BDAutoTrackExperimentGroup *> *)groups;

/**
 实验的初始化
 
 @param key 实验key，必须与abtest平台的“配置参数”名字保持一致
 @param group 实验组
 @return BDAutoTrackExperiment对象
 */
- (instancetype)initWithKey:(NSString *)key group:(BDAutoTrackExperimentGroup *)group;


- (void)addGroup:(BDAutoTrackExperimentGroup *)group;

- (void)removeGroup:(BDAutoTrackExperimentGroup *)group;

@end

NS_ASSUME_NONNULL_END
