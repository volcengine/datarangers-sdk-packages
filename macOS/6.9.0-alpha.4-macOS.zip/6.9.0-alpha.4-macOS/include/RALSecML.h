//
//  RALSecML.h
//  RangersAppLog
//
//  Created by 朱元清 on 2021/4/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RALSecML : NSObject

+ (void)bootMSSecML;

@end

NS_ASSUME_NONNULL_END
