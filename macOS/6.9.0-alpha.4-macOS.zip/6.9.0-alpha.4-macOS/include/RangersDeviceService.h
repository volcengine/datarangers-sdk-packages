//
//  RangersDeviceService.h
//  RangersAppLog
//
//  Created by 陈奕 on 2021/2/22.
//

#import <Foundation/Foundation.h>
#import <OneKit/OKServices.h>

NS_ASSUME_NONNULL_BEGIN

@interface RangersDeviceService : NSObject<OKDeviceService>

@end

NS_ASSUME_NONNULL_END
