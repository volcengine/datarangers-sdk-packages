/// AppLog Cross-Platform SDK By Rust.
/// Help doc: https://bytedance.feishu.cn/wiki/BhsUwADEcilH8hkrZT4c3q0lndf

#pragma once

#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

namespace applog {

/// c header，will create applogrs.hpp
///
/// C端定义的客户端响应体
struct HttpClientResponse {
  uint64_t code;
  const char *data;
};

extern "C" {

/// # Safety
/// Set custom domain, example: "log.xx.com", default is log.snssdk.com
void setCustomDomain(const char *host);

/// # Safety
/// Set custom domains for custom host and abtest host
void setCustomAndAbTestDomain(const char *custom_host, const char *abtest_host);

/// # Safety
/// Set if auto start to run workers
void setAutoStart(unsigned int enabled);

/// # Safety
/// Initialize inner applog sdk with app_id and channel
void init(const char *appid, const char *channel);

/// # Safety
/// Initialize rangers applog sdk with app_id and channel
void init_rangers(const char *appid, const char *channel);

/// # Safety
/// start applog by manual
void start();

/// # Safety
/// Collect a event
void onEvent(const char *event, const char *params);

/// # Safety
/// Collect a impression
void onImpression(const char *data);

/// # Safety
/// Add new custom common params
void addCustomHeader(const char *key, const char *value);

/// # Safety
/// Remove custom common params
void removeCustomHeader(const char *key);

/// # Safety
/// Set top common params to header, same level with aid
void setHeader(const char *key, const char *value);

/// # Safety
/// Query current did
uint64_t getDeviceId();

/// # Safety
/// Set did and disable auto register
void setDeviceId(unsigned long long did);

/// # Safety
/// Query current bd did
const char *getBdDid();

/// # Safety
/// Set user_unique_id
void setUserUniqueId(const char *uuid);

/// # Safety
/// Set user_unique_id
void setAutoRegisterWhenUuidChanged(unsigned int enabled);

/// # Safety
/// Set user_id
void setUserId(unsigned long long uuid);

/// # Safety
/// Set user_type
void setUserType(unsigned char t);

/// # Safety
/// Disable auto request device register to get did
void disableAutoRegister();

/// # Safety
/// Disable auto request active check
void disableAutoActive();

/// # Safety
/// Disable print log
void setLogEnabled(unsigned int enabled);

/// # Safety
/// Set data storage directory on disk
void setDbDir(const char *dir);

/// # Safety
/// flush events to report, only once flush work in 10s period
void flush();

/// # Safety
/// http proxy, example: https://127.0.0.2:8888
void setHttpProxy(const char *url);

/// # Safety
/// enable et verify report
void setEventVerifyEnabled(unsigned int enabled);

/// # Safety
/// launch
void launch();

/// # Safety
/// terminate
void terminate();

/// # Safety
/// Add a device_id listener
void registerDidObserver(void (*observer)(uint64_t, uint64_t));

/// # Safety
/// Add a bd_did listener
void registerBdDidObserver(void (*observer)(char*));

/// # Safety
/// Set applog http client
void setHttpClient(const HttpClientResponse *(*post)(const char*,
                                                     const uint8_t*,
                                                     uint64_t,
                                                     const char*));

/// # Safety
/// Query current session id
const char *getSessionId();

/// # Safety
/// set encrypt is enable
void setEncryptEnabled(unsigned int enabled);

/// # Safety
/// set compress is enable
void setCompressEnabled(unsigned int enabled);

/// # Safety
/// set uid enable is enable（to fix event user_id）
void setUidEnabled(unsigned int enabled);

/// # Safety
/// set if send pack by size, default max size is 100kb
void setSendBySizeLimit(unsigned int enabled);

/// # Safety
/// set track event is enabled
void setTrackEventEnabled(unsigned int enabled);

/// # Safety
/// set events upload enabled
void setReportEventEnabled(unsigned int enabled);

/// # Safety
/// set if enable inner monitor, default open
void setMonitorEnabled(unsigned int enabled);

/// # Safety
/// Query time sync，will copy to input array[server_time,local_time] and out len
void getTimeSync(uint64_t *out_ptr, size_t *out_len);

/// # Safety
/// set if enable abtest, default false
void setAbTestEnabled(unsigned int enabled);

/// # Safety
/// Query abtest config value or defaultValue
const char *getAbTestConfig(const char *key, const char *default_value);

/// # Safety
/// Query all abtest config
const char *getAllAbTestConfigs();

/// # Safety
/// set http request header with key and value
void setHttpHeader(const char *key, const char *value);

} // extern "C"

} // namespace applog
